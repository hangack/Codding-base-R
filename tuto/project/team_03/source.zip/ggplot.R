library(tidyverse)

loan_data <- read.csv("data/cleaned_loan_data.csv", stringsAsFactors = FALSE)
dim(loan_data)
glimpse(loan_data)

ggplot(data = loan_data) +
  geom_smooth(mapping = aes(x = age, y = annual_inc)) + 
  theme_minimal() + 
  labs(title = "smooth: age_income")

ggplot(data = loan_data) + 
  geom_bar(mapping = aes(x = age, fill = grade)) + 
  theme_minimal() + 
  labs(title = "Bar: age_stack_grade")

ggplot(data = loan_data) + 
  geom_bar(mapping = aes(x = grade, fill = home_ownership)) + 
  theme_minimal() + 
  labs(title = "Bar: grade_stack_home")

ggplot(data = loan_data, mapping = aes(x = home_ownership, y = loan_amnt)) + 
  geom_boxplot() +
  theme_minimal() + 
  labs(title = "Boxplot: home_loan")

bar <- ggplot(data = loan_data) + 
  geom_bar(
    mapping = aes(x = grade, fill = grade),
    width = 1
  ) + 
  theme_minimal() +
  labs(title = "Coord_polar: grade")
bar + coord_polar()

